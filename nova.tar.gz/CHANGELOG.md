# Changelog

# 2.2.0
* Add support for config files
* Add support for overriding desired-versions

# 2.1.0
* Support for `--context` flag to specify k8s context

# 2.0.2
* Added Helm version to output

# 2.0.1
* Fixed CI

# 2.0.0
* Changed output format
* Added new auth providers

## 1.0.1
* Build docker image for tags
* Fix #8: update release version during build

## 1.0.0

* Migrated existing functionality from private repository
